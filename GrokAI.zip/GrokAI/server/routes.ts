import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertConversationSchema, insertMessageSchema, insertUserSettingsSchema } from "@shared/schema";
import { z } from "zod";

const mockLLMResponse = async (message: string): Promise<string> => {
  // Simulate thinking time
  await new Promise(resolve => setTimeout(resolve, 2000 + Math.random() * 3000));
  
  // Generate contextual responses based on content
  if (message.toLowerCase().includes('financial') || message.toLowerCase().includes('market')) {
    return `Based on current market conditions and the query about ${message.slice(0, 50)}..., here's my analysis:

**Short Answer:**
The financial markets are showing mixed signals with volatility expected to continue in the near term.

**Key Points:**
- Market sentiment remains cautious due to economic uncertainty
- Technical indicators suggest a consolidation phase
- Risk management should be prioritized in current conditions

**Recommendation:**
Consider a diversified approach with regular portfolio rebalancing. Monitor key economic indicators and adjust positions accordingly.

Would you like me to elaborate on any specific aspect of this analysis?`;
  }
  
  if (message.toLowerCase().includes('code') || message.toLowerCase().includes('programming')) {
    return `I'd be happy to help with your coding question: "${message.slice(0, 50)}..."

**Code Review Recommendations:**
- Follow established coding conventions and best practices
- Implement proper error handling and validation
- Consider performance implications and optimization opportunities
- Add comprehensive documentation and comments

**Best Practices:**
1. Write clean, readable code
2. Use meaningful variable and function names
3. Implement proper testing coverage
4. Follow security guidelines

Would you like me to review specific code snippets or discuss particular programming concepts?`;
  }
  
  // Default response
  return `Thank you for your question: "${message.slice(0, 50)}..."

I'm CruxAGI AVi, your AI assistant. I can help you with:
- Financial analysis and market insights
- Code review and programming guidance  
- Research and data analysis
- General problem-solving

How can I assist you further with this topic?`;
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Conversations routes
  app.get('/api/conversations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const conversations = await storage.getUserConversations(userId);
      res.json(conversations);
    } catch (error) {
      console.error("Error fetching conversations:", error);
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });

  app.post('/api/conversations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const data = insertConversationSchema.parse({ ...req.body, userId });
      const conversation = await storage.createConversation(data);
      res.json(conversation);
    } catch (error) {
      console.error("Error creating conversation:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation error", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create conversation" });
      }
    }
  });

  app.get('/api/conversations/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const conversation = await storage.getConversation(id, userId);
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      res.json(conversation);
    } catch (error) {
      console.error("Error fetching conversation:", error);
      res.status(500).json({ message: "Failed to fetch conversation" });
    }
  });

  app.delete('/api/conversations/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      await storage.deleteConversation(id, userId);
      res.json({ message: "Conversation deleted" });
    } catch (error) {
      console.error("Error deleting conversation:", error);
      res.status(500).json({ message: "Failed to delete conversation" });
    }
  });

  // Messages routes
  app.get('/api/conversations/:id/messages', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const messages = await storage.getConversationMessages(id, userId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Settings routes
  app.get('/api/settings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      let settings = await storage.getUserSettings(userId);
      if (!settings) {
        // Create default settings
        settings = await storage.upsertUserSettings({ userId });
      }
      res.json(settings);
    } catch (error) {
      console.error("Error fetching settings:", error);
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  app.put('/api/settings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const data = insertUserSettingsSchema.parse({ ...req.body, userId });
      const settings = await storage.upsertUserSettings(data);
      res.json(settings);
    } catch (error) {
      console.error("Error updating settings:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation error", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update settings" });
      }
    }
  });

  const httpServer = createServer(app);

  // WebSocket server for real-time chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  interface AuthenticatedWebSocket extends WebSocket {
    userId?: string;
    conversationId?: string;
  }

  wss.on('connection', async (ws: AuthenticatedWebSocket, req) => {
    console.log('WebSocket connection established');

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'auth') {
          // Handle authentication
          ws.userId = message.userId;
          ws.send(JSON.stringify({ type: 'auth_success' }));
          return;
        }

        if (message.type === 'join_conversation') {
          ws.conversationId = message.conversationId;
          return;
        }

        if (message.type === 'chat_message') {
          const { conversationId, content } = message;
          
          if (!ws.userId || !conversationId) {
            ws.send(JSON.stringify({ type: 'error', message: 'Not authenticated or no conversation selected' }));
            return;
          }

          // Verify user owns the conversation
          const conversation = await storage.getConversation(conversationId, ws.userId);
          if (!conversation) {
            ws.send(JSON.stringify({ type: 'error', message: 'Conversation not found' }));
            return;
          }

          // Save user message
          const userMessage = await storage.createMessage({
            conversationId,
            role: 'user',
            content,
          });

          // Send user message confirmation
          ws.send(JSON.stringify({
            type: 'message_saved',
            message: userMessage
          }));

          // Send thinking indicator
          ws.send(JSON.stringify({
            type: 'thinking_start'
          }));

          // Generate AI response
          const aiResponseContent = await mockLLMResponse(content);

          // Save AI response
          const aiMessage = await storage.createMessage({
            conversationId,
            role: 'assistant',
            content: aiResponseContent,
          });

          // Send AI response
          ws.send(JSON.stringify({
            type: 'thinking_end'
          }));

          ws.send(JSON.stringify({
            type: 'ai_response',
            message: aiMessage
          }));

          // Update conversation title if it's the first message
          const messages = await storage.getConversationMessages(conversationId, ws.userId);
          if (messages.length === 2) { // User message + AI response
            const title = content.slice(0, 50) + (content.length > 50 ? '...' : '');
            await storage.updateConversationTitle(conversationId, title, ws.userId);
            
            ws.send(JSON.stringify({
              type: 'conversation_title_updated',
              conversationId,
              title
            }));
          }
        }
      } catch (error) {
        console.error('WebSocket error:', error);
        ws.send(JSON.stringify({ type: 'error', message: 'Server error' }));
      }
    });

    ws.on('close', () => {
      console.log('WebSocket connection closed');
    });
  });

  return httpServer;
}

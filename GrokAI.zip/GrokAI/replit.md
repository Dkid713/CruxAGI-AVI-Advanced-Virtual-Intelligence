# CruxAGI Chat Application

## Overview

CruxAGI is a modern AI chat application built as a full-stack TypeScript web application. The system provides a ChatGPT-like interface where users can engage in conversations with an AI assistant called "AVi". The application features real-time messaging, conversation management, user authentication via Replit Auth, and a responsive design with both desktop and mobile interfaces.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client is built using React with TypeScript, leveraging modern React patterns and hooks. The UI is constructed with shadcn/ui components built on top of Radix UI primitives, providing a consistent and accessible design system. The application uses Wouter for lightweight client-side routing and TanStack Query for server state management and caching. Styling is handled through Tailwind CSS with a dark theme configuration and custom CSS variables for consistent theming.

The frontend follows a component-based architecture with separate directories for UI components, pages, hooks, and utilities. Real-time communication is implemented through WebSocket connections, enabling live chat functionality without page refreshes.

### Backend Architecture
The server is built with Express.js and follows a modular architecture pattern. The main server entry point sets up middleware, routing, and error handling. The application uses a storage abstraction layer that implements database operations through a defined interface, making it easy to swap storage implementations.

API routes are organized into logical groups handling authentication, conversations, messages, and user settings. The server includes comprehensive logging middleware for API requests and implements proper error handling with structured responses.

### Database Design
The application uses PostgreSQL as the primary database with Drizzle ORM for type-safe database operations. The schema includes tables for users, conversations, messages, user settings, and session storage. Relationships are properly defined with foreign keys and cascade deletes to maintain data integrity.

Database migrations are managed through Drizzle Kit, and the connection utilizes Neon's serverless PostgreSQL offering for scalability and performance.

### Authentication System
User authentication is handled through Replit's OpenID Connect (OIDC) implementation using Passport.js. The system supports session management with PostgreSQL-backed session storage for persistence across requests. User profiles include basic information like name, email, and profile images.

The authentication flow includes proper session handling, user registration/login, and secure session storage with configurable TTL values.

### Real-time Communication
WebSocket functionality is implemented using the native WebSocket API with automatic reconnection logic. The system handles various message types including user messages, AI responses, thinking indicators, and error notifications. Connection state is managed through React hooks with proper cleanup and reconnection strategies.

### AI Integration
The current implementation includes a mock AI response system that simulates realistic chat behavior with contextual responses based on message content. The system is designed to be easily replaceable with actual LLM integrations while maintaining the same interface and user experience.

## External Dependencies

### Core Framework Dependencies
- **React & TypeScript**: Frontend framework with type safety
- **Express.js**: Backend web framework
- **Vite**: Build tool and development server with hot module replacement

### UI and Styling
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Radix UI**: Accessible component primitives for complex UI elements
- **shadcn/ui**: Pre-built component library built on Radix UI
- **Lucide React**: Icon library for consistent iconography

### Database and ORM
- **Drizzle ORM**: Type-safe ORM for database operations
- **Neon Database**: Serverless PostgreSQL database hosting
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### Authentication
- **Replit Auth**: OIDC-based authentication system
- **Passport.js**: Authentication middleware for Node.js
- **openid-client**: OpenID Connect client implementation

### State Management and Data Fetching
- **TanStack Query**: Server state management and caching
- **React Hook Form**: Form state management and validation
- **Zod**: Schema validation and type inference

### Real-time Communication
- **WebSocket (native)**: Real-time bidirectional communication
- **ws**: WebSocket library for Node.js server implementation

### Development and Build Tools
- **ESBuild**: Fast JavaScript bundler for production builds
- **TSX**: TypeScript execution environment for development
- **PostCSS & Autoprefixer**: CSS processing and vendor prefixing
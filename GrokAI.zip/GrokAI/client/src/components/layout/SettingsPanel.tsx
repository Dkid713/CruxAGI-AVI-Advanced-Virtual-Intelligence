import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import type { User, UserSettings } from "@shared/schema";

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  user?: User;
}

export default function SettingsPanel({ isOpen, onClose, user }: SettingsPanelProps) {
  const { toast } = useToast();

  const { data: settings, isLoading } = useQuery<UserSettings>({
    queryKey: ["/api/settings"],
    enabled: isOpen,
    retry: (failureCount, error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Session Expired",
          description: "Please sign in again.",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return false;
      }
      return failureCount < 3;
    },
  });

  const updateSettingsMutation = useMutation({
    mutationFn: async (data: Partial<UserSettings>) => {
      return await apiRequest("PUT", "/api/settings", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Settings Updated",
        description: "Your settings have been saved successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Session Expired",
          description: "Please sign in again.",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update settings. Please try again.",
        variant: "destructive",
      });
    },
  });

  const [localSettings, setLocalSettings] = useState<Partial<UserSettings>>({});

  const handleSettingChange = (key: keyof UserSettings, value: any) => {
    const newSettings = { ...localSettings, [key]: value };
    setLocalSettings(newSettings);
    updateSettingsMutation.mutate(newSettings);
  };

  const userInitials = user ? 
    (user.firstName?.charAt(0) || '') + (user.lastName?.charAt(0) || '') || 
    user.email?.charAt(0)?.toUpperCase() || 'U' : 'CA';

  const userName = user ? 
    (user.firstName && user.lastName ? `${user.firstName} ${user.lastName}` : user.email) || 'CruxAGI' : 'CruxAGI';

  const contextLengthValue = (localSettings as any).contextLength || settings?.contextLength || '32k';
  const contextLengthNumeric = parseInt(contextLengthValue.replace('k', ''));

  return (
    <div className={cn(
      "fixed inset-y-0 right-0 w-96 bg-card border-l border-border transform transition-transform duration-300 ease-in-out z-50 hidden lg:block",
      isOpen ? "translate-x-0" : "translate-x-full"
    )}>
      <div className="flex flex-col h-full">
        {/* Settings Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="text-lg font-semibold">Settings</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-accent rounded-lg transition-colors"
            data-testid="button-close-settings"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/>
            </svg>
          </button>
        </div>

        {/* Settings Content */}
        <div className="flex-1 overflow-y-auto scrollbar-thin p-6 space-y-6">
          {/* User Profile Section */}
          <div className="space-y-4">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-medium text-lg" data-testid="text-settings-user-initials">
                  {userInitials}
                </span>
              </div>
              <div className="flex-1">
                <h3 className="font-medium" data-testid="text-settings-username">{userName}</h3>
                <p className="text-sm text-muted-foreground" data-testid="text-settings-user-email">
                  {user?.email || 'CruxAGI@outlook.com'}
                </p>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button variant="secondary" size="sm">
                Manage
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.location.href = '/api/logout'}
                data-testid="button-logout"
              >
                Sign out
              </Button>
            </div>
          </div>

          {/* Network Settings */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.236-3.905 14.141 0M1.394 9.393c5.857-5.857 15.355-5.857 21.213 0"/>
                </svg>
                <div>
                  <p className="font-medium">Expose Ollama to the network</p>
                  <p className="text-sm text-muted-foreground">Allow other devices or services to access Ollama.</p>
                </div>
              </div>
              <Switch
                checked={(localSettings as any).exposeNetwork ?? settings?.exposeNetwork ?? true}
                onCheckedChange={(value) => handleSettingChange('exposeNetwork', value)}
                data-testid="switch-expose-network"
              />
            </div>
          </div>

          {/* Model Location */}
          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <svg className="w-5 h-5 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
              </svg>
              <div className="flex-1">
                <p className="font-medium">Model location</p>
                <p className="text-sm text-muted-foreground mb-3">Location where models are stored.</p>
                <div className="flex space-x-2">
                  <Input
                    value={(localSettings as any).modelLocation || settings?.modelLocation || "C:\\Users\\CruxAGI\\ollama\\models"}
                    onChange={(e) => handleSettingChange('modelLocation', e.target.value)}
                    className="flex-1"
                    data-testid="input-model-location"
                  />
                  <Button variant="secondary" size="sm">
                    Browse
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Context Length */}
          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <svg className="w-5 h-5 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
              </svg>
              <div className="flex-1">
                <p className="font-medium">Context length</p>
                <p className="text-sm text-muted-foreground mb-4">Context length determines how much of your conversation local LLMs can remember and use to generate responses.</p>
                
                <div className="space-y-3">
                  <Slider
                    value={[contextLengthNumeric]}
                    onValueChange={([value]) => handleSettingChange('contextLength', `${value}k`)}
                    min={4}
                    max={128}
                    step={4}
                    className="w-full"
                    data-testid="slider-context-length"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>4k</span>
                    <span>8k</span>
                    <span>16k</span>
                    <span>32k</span>
                    <span>64k</span>
                    <span>128k</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Airplane Mode */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/>
                </svg>
                <div>
                  <p className="font-medium">Airplane mode</p>
                  <p className="text-sm text-muted-foreground">Airplane mode keeps data local, disabling Turbo mode and web search.</p>
                </div>
              </div>
              <Switch
                checked={(localSettings as any).airplaneMode ?? settings?.airplaneMode ?? false}
                onCheckedChange={(value) => handleSettingChange('airplaneMode', value)}
                data-testid="switch-airplane-mode"
              />
            </div>
          </div>
        </div>

        {/* Settings Footer */}
        <div className="border-t border-border p-6">
          <Button
            variant="ghost"
            className="w-full text-sm text-muted-foreground hover:text-foreground"
            onClick={() => {
              setLocalSettings({});
              updateSettingsMutation.mutate({
                modelLocation: "C:\\Users\\CruxAGI\\ollama\\models",
                contextLength: "32k",
                exposeNetwork: true,
                airplaneMode: false,
                selectedModel: "gpt-oss:20b",
              });
            }}
            data-testid="button-reset-defaults"
          >
            Reset to defaults
          </Button>
        </div>
      </div>
    </div>
  );
}

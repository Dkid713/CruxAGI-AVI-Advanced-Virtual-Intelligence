import { cn } from "@/lib/utils";
import type { Conversation, User } from "@shared/schema";

interface MobileSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  conversations: Conversation[];
  onNewChat: () => void;
  onSelectConversation: (conversation: Conversation) => void;
  currentConversationId: string | null;
  user?: User;
}

export default function MobileSidebar({
  isOpen,
  onClose,
  conversations,
  onNewChat,
  onSelectConversation,
  currentConversationId,
  user
}: MobileSidebarProps) {
  const userInitials = user ? 
    (user.firstName?.charAt(0) || '') + (user.lastName?.charAt(0) || '') || 
    user.email?.charAt(0)?.toUpperCase() || 'U' : 'CA';

  const userName = user ? 
    (user.firstName && user.lastName ? `${user.firstName} ${user.lastName}` : user.email) || 'CruxAGI' : 'CruxAGI';

  return (
    <div className={cn(
      "fixed inset-y-0 left-0 w-80 bg-card border-r border-border transform transition-transform duration-300 ease-in-out z-50 lg:hidden",
      isOpen ? "translate-x-0" : "-translate-x-full"
    )}>
      <div className="flex flex-col h-full">
        {/* Mobile Sidebar Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">C</span>
            </div>
            <div>
              <h1 className="text-lg font-semibold">CruxAGI</h1>
              <p className="text-xs text-muted-foreground">AVi Assistant</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-accent rounded-lg transition-colors"
            data-testid="button-close-mobile-sidebar"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/>
            </svg>
          </button>
        </div>

        {/* Mobile Navigation Menu */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto scrollbar-thin">
          <button className="w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-accent transition-colors text-left">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
            </svg>
            <span>Search</span>
          </button>
          <button className="w-full flex items-center space-x-3 p-3 rounded-lg bg-accent text-accent-foreground transition-colors text-left">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
            </svg>
            <span>Chat</span>
          </button>
          <button className="w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-accent transition-colors text-left">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"/>
            </svg>
            <span>Voice</span>
          </button>

          {/* Mobile Chat History */}
          <div className="border-t border-border pt-4 mt-4">
            <h3 className="text-sm font-medium text-muted-foreground mb-3">Recent Chats</h3>
            <div className="space-y-2">
              {conversations.length === 0 ? (
                <p className="text-xs text-muted-foreground italic">No conversations yet</p>
              ) : (
                conversations.slice(0, 10).map((conversation) => (
                  <button
                    key={conversation.id}
                    onClick={() => onSelectConversation(conversation)}
                    className={cn(
                      "w-full text-left p-2 hover:bg-accent rounded-lg transition-colors",
                      currentConversationId === conversation.id && "bg-accent"
                    )}
                    data-testid={`mobile-conversation-${conversation.id}`}
                  >
                    <p className="text-sm font-medium truncate">{conversation.title}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {new Date(conversation.createdAt!).toLocaleDateString()}
                    </p>
                  </button>
                ))
              )}
            </div>
          </div>
        </nav>

        {/* Mobile User Profile */}
        <div className="border-t border-border p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-medium text-sm" data-testid="text-mobile-user-initials">
                  {userInitials}
                </span>
              </div>
              <div>
                <p className="text-sm font-medium" data-testid="text-mobile-username">{userName}</p>
                <p className="text-xs text-muted-foreground" data-testid="text-mobile-user-email">
                  {user?.email || 'CruxAGI@outlook.com'}
                </p>
              </div>
            </div>
            <button className="p-2 hover:bg-accent rounded-lg transition-colors">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

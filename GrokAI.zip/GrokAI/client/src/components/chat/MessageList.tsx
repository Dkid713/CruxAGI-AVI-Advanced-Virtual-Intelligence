import { useEffect, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import TypingIndicator from "../ui/typing-indicator";
import type { Message } from "@shared/schema";

interface MessageListProps {
  messages: Message[];
  isThinking: boolean;
  conversationId: string | null;
}

export default function MessageList({ messages, isThinking, conversationId }: MessageListProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const createConversationMutation = useMutation({
    mutationFn: async (title: string) => {
      const response = await apiRequest("POST", "/api/conversations", { title });
      return response.json();
    },
    onSuccess: (conversation) => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      navigate(`/chat/${conversation.id}`);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Session Expired",
          description: "Please sign in again.",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create conversation. Please try again.",
        variant: "destructive",
      });
    },
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isThinking]);

  const handleQuickAction = (action: string) => {
    const prompts = {
      'Financial Analysis': 'Help me analyze current market trends and investment opportunities',
      'Code Review': 'Review and optimize my code for better performance and best practices',
      'Research': 'Help me research and analyze complex topics with detailed insights'
    };
    
    const prompt = prompts[action as keyof typeof prompts] || `Help me with ${action.toLowerCase()}`;
    
    if (!conversationId) {
      // Create new conversation
      createConversationMutation.mutate(action);
    }
  };

  const handleSamplePrompt = (prompt: string) => {
    if (!conversationId) {
      const title = prompt.length > 50 ? prompt.slice(0, 50) + '...' : prompt;
      createConversationMutation.mutate(title);
    }
  };

  // Show welcome state if no conversation is selected
  if (!conversationId) {
    return (
      <div className="flex-1 overflow-y-auto scrollbar-thin p-4">
        <div className="flex flex-col items-center justify-center h-full text-center max-w-2xl mx-auto">
          <div className="mb-8">
            <div className="w-20 h-20 bg-primary rounded-2xl flex items-center justify-center mb-4 mx-auto">
              <span className="text-primary-foreground font-bold text-2xl">C</span>
            </div>
            <h1 className="text-4xl font-bold mb-2">CruxAGI</h1>
            <p className="text-muted-foreground text-lg">What do you want to know?</p>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full max-w-4xl mb-8">
            <button
              onClick={() => handleQuickAction('Financial Analysis')}
              className="p-4 bg-card hover:bg-accent rounded-xl border border-border transition-colors text-left group"
              data-testid="button-quick-financial"
            >
              <div className="flex items-center space-x-3 mb-2">
                <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                </svg>
                <span className="font-medium">Financial Analysis</span>
              </div>
              <p className="text-sm text-muted-foreground group-hover:text-foreground transition-colors">
                Analyze market trends and investment opportunities
              </p>
            </button>

            <button
              onClick={() => handleQuickAction('Code Review')}
              className="p-4 bg-card hover:bg-accent rounded-xl border border-border transition-colors text-left group"
              data-testid="button-quick-code"
            >
              <div className="flex items-center space-x-3 mb-2">
                <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"/>
                </svg>
                <span className="font-medium">Code Review</span>
              </div>
              <p className="text-sm text-muted-foreground group-hover:text-foreground transition-colors">
                Get help with programming and code optimization
              </p>
            </button>

            <button
              onClick={() => handleQuickAction('Research')}
              className="p-4 bg-card hover:bg-accent rounded-xl border border-border transition-colors text-left group"
              data-testid="button-quick-research"
            >
              <div className="flex items-center space-x-3 mb-2">
                <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                </svg>
                <span className="font-medium">Research</span>
              </div>
              <p className="text-sm text-muted-foreground group-hover:text-foreground transition-colors">
                Explore topics and get comprehensive insights
              </p>
            </button>
          </div>

          {/* Sample Prompts */}
          <div className="w-full max-w-2xl space-y-2">
            <button
              onClick={() => handleSamplePrompt("Explain the concept of compound interest with examples")}
              className="w-full p-3 bg-muted hover:bg-accent rounded-lg text-left transition-colors"
              data-testid="button-sample-prompt-1"
            >
              <span className="text-sm">"Explain the concept of compound interest with examples"</span>
            </button>
            <button
              onClick={() => handleSamplePrompt("Review this Python code for optimization opportunities")}
              className="w-full p-3 bg-muted hover:bg-accent rounded-lg text-left transition-colors"
              data-testid="button-sample-prompt-2"
            >
              <span className="text-sm">"Review this Python code for optimization opportunities"</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Show chat messages
  return (
    <div className="flex-1 overflow-y-auto scrollbar-thin p-4">
      <div className="space-y-6 max-w-4xl mx-auto w-full">
        {messages.map((message) => (
          <div key={message.id} className={message.role === 'user' ? "flex justify-end" : "flex items-start space-x-3"}>
            {message.role === 'assistant' && (
              <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-accent-foreground font-medium text-sm">C</span>
              </div>
            )}
            <div className={message.role === 'user' 
              ? "bg-primary text-primary-foreground p-4 rounded-2xl rounded-tr-md max-w-xs lg:max-w-2xl" 
              : "bg-card border border-border p-4 rounded-2xl rounded-tl-md flex-1 max-w-none lg:max-w-3xl"
            }>
              <div className="prose prose-invert max-w-none text-sm whitespace-pre-wrap">
                {message.content}
              </div>
            </div>
          </div>
        ))}

        {isThinking && (
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center flex-shrink-0">
              <span className="text-accent-foreground font-medium text-sm">C</span>
            </div>
            <div className="bg-card border border-border p-4 rounded-2xl rounded-tl-md flex-1">
              <TypingIndicator />
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>
    </div>
  );
}

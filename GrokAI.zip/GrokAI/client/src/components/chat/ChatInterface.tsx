import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useWebSocket } from "../../hooks/useWebSocket";
import { useAuth } from "../../hooks/useAuth";
import MessageList from "./MessageList";
import MessageInput from "./MessageInput";
import type { Message } from "@shared/schema";

interface ChatInterfaceProps {
  conversationId: string | null;
}

export default function ChatInterface({ conversationId }: ChatInterfaceProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [isThinking, setIsThinking] = useState(false);

  const { sendMessage, isConnected } = useWebSocket({
    onMessage: (data: any) => {
      switch (data.type) {
        case 'message_saved':
          setMessages(prev => [...prev, data.message]);
          break;
        case 'thinking_start':
          setIsThinking(true);
          break;
        case 'thinking_end':
          setIsThinking(false);
          break;
        case 'ai_response':
          setMessages(prev => [...prev, data.message]);
          break;
        case 'error':
          toast({
            title: "Error",
            description: data.message,
            variant: "destructive",
          });
          setIsThinking(false);
          break;
      }
    },
    userId: (user as any)?.id
  });

  const { data: fetchedMessages, isLoading: messagesLoading } = useQuery<Message[]>({
    queryKey: ["/api/conversations", conversationId, "messages"],
    enabled: !!conversationId,
    retry: (failureCount, error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Session Expired",
          description: "Please sign in again.",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return false;
      }
      return failureCount < 3;
    },
  });

  // Update messages when fetched messages change
  useEffect(() => {
    if (fetchedMessages) {
      setMessages(fetchedMessages);
    } else {
      setMessages([]);
    }
  }, [fetchedMessages]);

  // Join conversation when websocket connects
  useEffect(() => {
    if (conversationId && isConnected) {
      sendMessage({
        type: 'join_conversation',
        conversationId
      });
    }
  }, [conversationId, isConnected, sendMessage]);

  const handleSendMessage = (content: string) => {
    if (!isConnected) {
      toast({
        title: "Connection Error",
        description: "Not connected to server. Please refresh the page.",
        variant: "destructive",
      });
      return;
    }

    if (conversationId) {
      sendMessage({
        type: 'chat_message',
        conversationId,
        content
      });
    }
  };

  if (conversationId && messagesLoading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center mx-auto mb-2 animate-pulse">
            <span className="text-primary-foreground font-bold text-sm">C</span>
          </div>
          <p className="text-muted-foreground text-sm">Loading messages...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      <MessageList 
        messages={messages} 
        isThinking={isThinking} 
        conversationId={conversationId}
      />
      <MessageInput 
        onSendMessage={handleSendMessage} 
        disabled={!isConnected || isThinking}
        conversationId={conversationId}
      />
    </div>
  );
}

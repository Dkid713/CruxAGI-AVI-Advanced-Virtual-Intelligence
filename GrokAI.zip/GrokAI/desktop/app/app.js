class CruxAGIApp {
    constructor() {
        this.currentView = 'chat';
        this.currentChatId = null;
        this.isConnected = false;
        this.config = {};
        this.conversations = [];
        this.messages = [];
        this.models = [];
        
        this.init();
    }

    async init() {
        await this.loadConfig();
        this.setupEventListeners();
        this.setupTitleBarControls();
        this.loadModels();
        this.loadConversations();
        this.updateConnectionStatus();
    }

    async loadConfig() {
        try {
            this.config = await window.electronAPI.getConfig();
            this.updateSettingsUI();
        } catch (error) {
            console.error('Failed to load config:', error);
        }
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', () => {
                const view = item.dataset.nav;
                this.switchView(view);
            });
        });

        // New chat
        document.getElementById('new-chat-btn').addEventListener('click', () => {
            this.createNewChat();
        });

        // Chat input
        const chatInput = document.getElementById('chat-input');
        const sendBtn = document.getElementById('send-btn');
        
        chatInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });

        chatInput.addEventListener('input', () => {
            this.autoResizeTextarea(chatInput);
            sendBtn.disabled = !chatInput.value.trim();
        });

        sendBtn.addEventListener('click', () => {
            this.sendMessage();
        });

        // Quick actions
        document.querySelectorAll('.quick-action').forEach(button => {
            button.addEventListener('click', () => {
                const prompt = button.dataset.prompt;
                this.sendQuickMessage(prompt);
            });
        });

        // Settings
        document.getElementById('change-model-location').addEventListener('click', () => {
            this.changeModelLocation();
        });

        document.getElementById('restart-setup').addEventListener('click', () => {
            this.restartSetup();
        });

        // Settings changes
        document.getElementById('context-length-setting').addEventListener('change', (e) => {
            this.updateSetting('contextLength', e.target.value);
        });

        document.getElementById('airplane-mode-setting').addEventListener('change', (e) => {
            this.updateSetting('airplaneMode', e.target.checked);
        });

        document.getElementById('expose-network-setting').addEventListener('change', (e) => {
            this.updateSetting('exposeNetwork', e.target.checked);
        });
    }

    setupTitleBarControls() {
        document.getElementById('minimize-btn').addEventListener('click', () => {
            window.electronAPI.minimizeWindow();
        });

        document.getElementById('maximize-btn').addEventListener('click', () => {
            window.electronAPI.maximizeWindow();
        });

        document.getElementById('close-btn').addEventListener('click', () => {
            window.electronAPI.closeWindow();
        });
    }

    switchView(viewName) {
        // Update navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-nav="${viewName}"]`).classList.add('active');

        // Update content
        document.querySelectorAll('.content-view').forEach(view => {
            view.classList.remove('active');
        });
        document.getElementById(`${viewName}-view`).classList.add('active');

        this.currentView = viewName;

        // Load view-specific data
        if (viewName === 'models') {
            this.loadModels();
        } else if (viewName === 'settings') {
            this.updateSettingsUI();
        }
    }

    createNewChat() {
        this.currentChatId = null;
        this.messages = [];
        this.renderMessages();
        this.switchView('chat');
        document.getElementById('chat-input').focus();
    }

    async sendMessage() {
        const input = document.getElementById('chat-input');
        const message = input.value.trim();
        
        if (!message) return;

        // Add user message
        this.addMessage({
            id: Date.now().toString(),
            role: 'user',
            content: message,
            timestamp: new Date()
        });

        input.value = '';
        this.autoResizeTextarea(input);
        
        // Show thinking indicator
        this.showThinkingIndicator();

        // Simulate AI response (in a real app, this would call your local LLM)
        setTimeout(() => {
            this.hideThinkingIndicator();
            this.addMessage({
                id: (Date.now() + 1).toString(),
                role: 'assistant',
                content: this.generateMockResponse(message),
                timestamp: new Date()
            });
        }, 2000 + Math.random() * 3000);
    }

    sendQuickMessage(prompt) {
        document.getElementById('chat-input').value = prompt;
        this.sendMessage();
    }

    addMessage(message) {
        this.messages.push(message);
        this.renderMessages();
        this.scrollToBottom();

        // Save conversation if it's the first message
        if (this.messages.length === 1 && message.role === 'user') {
            this.saveConversation(message.content);
        }
    }

    renderMessages() {
        const container = document.getElementById('chat-messages');
        const welcomeScreen = document.getElementById('welcome-screen');
        
        if (this.messages.length === 0) {
            welcomeScreen.style.display = 'flex';
            return;
        }

        welcomeScreen.style.display = 'none';
        
        const messagesHTML = this.messages.map(message => {
            if (message.role === 'user') {
                return `
                    <div class="message user">
                        <div class="message-content">${message.content}</div>
                    </div>
                `;
            } else {
                return `
                    <div class="message assistant">
                        <div class="message-avatar">C</div>
                        <div class="message-content">${message.content}</div>
                    </div>
                `;
            }
        }).join('');

        container.innerHTML = `
            <div class="messages-list">
                ${messagesHTML}
            </div>
            ${this.isThinking ? '<div class="thinking-indicator"><div class="thinking-dots"><div class="thinking-dot"></div><div class="thinking-dot"></div><div class="thinking-dot"></div></div><span>Thinking...</span></div>' : ''}
        `;
    }

    showThinkingIndicator() {
        this.isThinking = true;
        this.renderMessages();
        this.scrollToBottom();
    }

    hideThinkingIndicator() {
        this.isThinking = false;
        this.renderMessages();
    }

    scrollToBottom() {
        const container = document.getElementById('chat-messages');
        container.scrollTop = container.scrollHeight;
    }

    autoResizeTextarea(textarea) {
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
    }

    generateMockResponse(userMessage) {
        const responses = {
            'financial': `Based on your query about "${userMessage.slice(0, 50)}...", here's my financial analysis:

**Market Overview:**
The current market conditions show mixed signals with volatility in key sectors. Here are the key points to consider:

- **Technology stocks** are showing resilience with strong fundamentals
- **Energy sector** remains volatile due to geopolitical factors  
- **Interest rates** continue to impact growth stocks

**Recommendations:**
1. Diversify your portfolio across multiple sectors
2. Consider dollar-cost averaging for volatile periods
3. Focus on companies with strong balance sheets

Would you like me to dive deeper into any specific aspect of this analysis?`,

            'code': `I'd be happy to help with your programming question: "${userMessage.slice(0, 50)}..."

**Code Review Best Practices:**
- Follow consistent naming conventions
- Implement proper error handling
- Add comprehensive documentation
- Optimize for readability and maintainability

**Performance Considerations:**
- Use appropriate data structures
- Minimize computational complexity
- Implement caching where beneficial
- Profile critical code paths

**Security Guidelines:**
- Validate all inputs
- Use parameterized queries
- Implement proper authentication
- Follow principle of least privilege

Would you like me to review specific code snippets or discuss particular programming concepts?`,

            'default': `Thank you for your question: "${userMessage.slice(0, 50)}..."

I'm CruxAGI AVi, your local AI assistant running entirely on your machine. I can help you with:

- **Financial Analysis** - Market insights and investment guidance
- **Programming** - Code review, debugging, and best practices  
- **Research** - Information gathering and analysis
- **Problem Solving** - Structured approaches to complex challenges

Since I'm running locally, all our conversations stay private on your device. How can I assist you further with this topic?`
        };

        const message = userMessage.toLowerCase();
        
        if (message.includes('financial') || message.includes('market') || message.includes('investment')) {
            return responses.financial;
        } else if (message.includes('code') || message.includes('programming') || message.includes('bug')) {
            return responses.code;
        } else {
            return responses.default;
        }
    }

    saveConversation(title) {
        const conversation = {
            id: Date.now().toString(),
            title: title.length > 50 ? title.slice(0, 50) + '...' : title,
            timestamp: new Date(),
            messageCount: 1
        };

        this.conversations.unshift(conversation);
        this.currentChatId = conversation.id;
        this.updateChatHistory();
    }

    loadConversations() {
        // In a real app, load from storage
        this.conversations = [
            {
                id: '1',
                title: 'Financial market analysis for Q4',
                timestamp: new Date(Date.now() - 86400000),
                messageCount: 8
            },
            {
                id: '2', 
                title: 'Code review for React components',
                timestamp: new Date(Date.now() - 172800000),
                messageCount: 12
            }
        ];
        this.updateChatHistory();
    }

    updateChatHistory() {
        const historyList = document.getElementById('history-list');
        
        if (this.conversations.length === 0) {
            historyList.innerHTML = '<p style="color: #8b9bb5; font-size: 12px; text-align: center;">No conversations yet</p>';
            return;
        }

        const historyHTML = this.conversations.map(conv => `
            <div class="history-item ${conv.id === this.currentChatId ? 'active' : ''}" 
                 data-chat-id="${conv.id}">
                <div class="history-title">${conv.title}</div>
                <div class="history-time">${this.formatTime(conv.timestamp)}</div>
            </div>
        `).join('');

        historyList.innerHTML = historyHTML;

        // Add click listeners
        historyList.querySelectorAll('.history-item').forEach(item => {
            item.addEventListener('click', () => {
                const chatId = item.dataset.chatId;
                this.loadConversation(chatId);
            });
        });
    }

    loadConversation(chatId) {
        // In a real app, load messages from storage
        this.currentChatId = chatId;
        this.messages = []; // Load actual messages
        this.renderMessages();
        this.switchView('chat');
        this.updateChatHistory();
    }

    formatTime(date) {
        const now = new Date();
        const diff = now - date;
        const days = Math.floor(diff / 86400000);
        
        if (days === 0) {
            return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        } else if (days === 1) {
            return 'Yesterday';
        } else if (days < 7) {
            return `${days} days ago`;
        } else {
            return date.toLocaleDateString();
        }
    }

    loadModels() {
        // In a real app, load available models from the system
        this.models = [
            {
                name: 'Llama 2 7B',
                size: '3.8 GB',
                status: 'installed',
                description: 'General purpose conversational AI model'
            },
            {
                name: 'Code Llama 7B',
                size: '3.8 GB', 
                status: 'available',
                description: 'Specialized model for programming tasks'
            },
            {
                name: 'Mistral 7B',
                size: '4.1 GB',
                status: 'available',
                description: 'Fast and efficient general purpose model'
            }
        ];
        this.updateModelsUI();
    }

    updateModelsUI() {
        const modelsList = document.getElementById('models-list');
        
        const modelsHTML = this.models.map(model => `
            <div class="model-card">
                <div class="model-info">
                    <h3>${model.name}</h3>
                    <p>Size: ${model.size}</p>
                    <p>${model.description}</p>
                </div>
                <div class="model-actions">
                    ${model.status === 'installed' 
                        ? '<button class="btn-secondary">Uninstall</button>' 
                        : '<button class="btn-primary">Download</button>'}
                </div>
            </div>
        `).join('');

        modelsList.innerHTML = modelsHTML;
    }

    updateSettingsUI() {
        if (this.config.modelLocation) {
            document.getElementById('model-location-setting').value = this.config.modelLocation;
        }
        
        if (this.config.contextLength) {
            document.getElementById('context-length-setting').value = this.config.contextLength;
        }

        document.getElementById('airplane-mode-setting').checked = this.config.airplaneMode || false;
        document.getElementById('expose-network-setting').checked = this.config.exposeNetwork || false;
    }

    async changeModelLocation() {
        try {
            const newPath = await window.electronAPI.selectFolder();
            if (newPath) {
                await this.updateSetting('modelLocation', newPath);
                document.getElementById('model-location-setting').value = newPath;
            }
        } catch (error) {
            console.error('Error changing model location:', error);
        }
    }

    async updateSetting(key, value) {
        try {
            this.config[key] = value;
            await window.electronAPI.saveConfig(this.config);
        } catch (error) {
            console.error('Error updating setting:', error);
        }
    }

    async restartSetup() {
        try {
            this.config.isFirstRun = true;
            await window.electronAPI.saveConfig(this.config);
            await window.electronAPI.restartApp();
        } catch (error) {
            console.error('Error restarting setup:', error);
        }
    }

    updateConnectionStatus() {
        const statusEl = document.getElementById('connection-status');
        const dot = statusEl.querySelector('.status-dot');
        const text = statusEl.querySelector('span');
        
        if (this.config.airplaneMode) {
            dot.style.background = '#22c55e';
            text.textContent = 'Local Mode';
        } else {
            dot.style.background = '#f59e0b';
            text.textContent = 'Network Mode';
        }
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.cruxagiApp = new CruxAGIApp();
});
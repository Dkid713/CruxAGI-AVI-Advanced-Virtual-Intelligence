const { contextBridge, ipcRenderer } = require('electron');

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
contextBridge.exposeInMainWorld('electronAPI', {
  // Configuration
  getConfig: () => ipcRenderer.invoke('get-config'),
  saveConfig: (config) => ipcRenderer.invoke('save-config', config),
  completeSetup: (config) => ipcRenderer.invoke('complete-setup', config),
  
  // File system
  selectFolder: () => ipcRenderer.invoke('select-folder'),
  createDirectory: (path) => ipcRenderer.invoke('create-directory', path),
  checkDirectory: (path) => ipcRenderer.invoke('check-directory', path),
  
  // Application controls
  restartApp: () => ipcRenderer.invoke('restart-app'),
  quitApp: () => ipcRenderer.invoke('quit-app'),
  minimizeWindow: () => ipcRenderer.invoke('minimize-window'),
  maximizeWindow: () => ipcRenderer.invoke('maximize-window'),
  closeWindow: () => ipcRenderer.invoke('close-window'),

  // Platform info
  platform: process.platform,
  
  // Events
  onConfigChanged: (callback) => {
    ipcRenderer.on('config-changed', callback);
  },
  
  removeAllListeners: (channel) => {
    ipcRenderer.removeAllListeners(channel);
  }
});

// Prevent the renderer process from accessing Node.js
delete global.require;
delete global.exports;
delete global.module;
delete global.Buffer;
delete global.process;
# CruxAGI Desktop

A standalone desktop application that brings the power of CruxAGI AVi to your local machine with complete privacy and a configuration wizard for easy setup.

## Features

✨ **Complete Privacy** - All conversations and data stay on your machine
🚀 **Configuration Wizard** - Easy setup process for first-time users
🎨 **Dark Theme Interface** - Beautiful, modern UI matching Grok's aesthetic
💬 **Real-time Chat** - Instant responses from your local AI assistant
📚 **Model Management** - Download and manage different AI models
⚙️ **Customizable Settings** - Adjust performance and privacy settings
🖥️ **Cross-Platform** - Available for Windows, macOS, and Linux

## Installation

### Download Pre-built Binaries
Visit the [Releases](https://github.com/cruxagi/desktop/releases) page to download pre-built binaries for your platform:

- **Windows**: `CruxAGI-Desktop-Setup-1.0.0.exe`
- **macOS**: `CruxAGI-Desktop-1.0.0.dmg`
- **Linux**: `CruxAGI-Desktop-1.0.0.AppImage` or `.deb` package

### Build from Source

1. **Clone the repository**
   ```bash
   git clone https://github.com/cruxagi/desktop.git
   cd desktop
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Run in development mode**
   ```bash
   npm run dev
   ```

4. **Build for distribution**
   ```bash
   npm run dist
   ```

## Configuration Wizard

When you first launch CruxAGI Desktop, you'll be guided through a 5-step setup wizard:

### Step 1: Welcome
Introduction to the application and overview of configuration options.

### Step 2: Model Storage
Choose where to store AI models on your local machine. Recommended: at least 50GB free space.

### Step 3: Performance Settings
- **Context Length**: How much conversation history the AI remembers (4k-64k tokens)
- **Default Model**: Choose from Llama 2, Code Llama, Mistral, or custom models
- **GPU Acceleration**: Enable hardware acceleration if available

### Step 4: Privacy & Network
- **Airplane Mode**: Keep all data local (recommended for maximum privacy)
- **Network Access**: Allow other devices to access your local AI server
- **Server Port**: Configure the local server port (default: 11434)

### Step 5: Complete
Review your configuration and launch the application.

## Application Features

### Chat Interface
- **Welcome Screen**: Quick actions for Financial Analysis, Code Review, and Research
- **Real-time Messaging**: Instant responses with typing indicators
- **Conversation History**: Access previous chats from the sidebar
- **Message Formatting**: Rich text support for code, lists, and formatting

### Model Management
- **Download Models**: Easily download new AI models
- **Model Information**: View model sizes, descriptions, and capabilities
- **Storage Management**: Monitor disk usage and remove unused models

### Settings Panel
- **Model Configuration**: Change storage location and context settings
- **Privacy Controls**: Toggle airplane mode and network exposure
- **Application Settings**: Restart the setup wizard or adjust preferences

## Technical Details

### Architecture
- **Frontend**: Electron with native web technologies
- **Backend**: Local AI server integration
- **Storage**: Local file system for models and conversations
- **Security**: No data leaves your machine in airplane mode

### System Requirements
- **RAM**: 8GB minimum, 16GB recommended
- **Storage**: 50GB+ free space for models
- **OS**: Windows 10+, macOS 10.15+, or Linux (Ubuntu 18.04+)
- **Network**: Internet connection for initial model downloads

### Model Support
- **Llama 2**: 7B, 13B, and 70B parameter models
- **Code Llama**: Programming-focused variants
- **Mistral**: Efficient general-purpose models
- **Custom Models**: Support for GGUF and other formats

## Privacy & Security

🔒 **Local Processing**: All AI processing happens on your device
🚫 **No Telemetry**: No data collection or usage tracking
🔐 **Secure Storage**: Conversations stored locally with encryption
✈️ **Airplane Mode**: Complete offline operation when enabled
🛡️ **Network Isolation**: Configurable network access controls

## Development

### Project Structure
```
desktop/
├── main.js          # Main Electron process
├── preload.js       # Preload script for security
├── app/             # Main application UI
│   ├── index.html   # Application HTML
│   ├── app.css      # Application styles
│   └── app.js       # Application logic
├── wizard/          # Setup wizard
│   ├── index.html   # Wizard HTML
│   ├── wizard.css   # Wizard styles
│   └── wizard.js    # Wizard logic
└── assets/          # Application assets
```

### Building

1. **Development Build**
   ```bash
   npm run dev
   ```

2. **Production Build**
   ```bash
   npm run build
   ```

3. **Create Distributables**
   ```bash
   npm run dist
   ```

### Contributing
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## Support

- **Issues**: Report bugs on [GitHub Issues](https://github.com/cruxagi/desktop/issues)
- **Documentation**: Visit our [Wiki](https://github.com/cruxagi/desktop/wiki)
- **Community**: Join our [Discord](https://discord.gg/cruxagi)

## License

MIT License - see [LICENSE](LICENSE) file for details.

---

Built with ❤️ by the CruxAGI team
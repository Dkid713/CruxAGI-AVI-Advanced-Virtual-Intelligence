# Running CruxAGI Desktop

## Quick Start

To test the desktop application:

1. **Navigate to the desktop directory**
   ```bash
   cd desktop
   ```

2. **Install Electron dependencies** (if not already installed)
   ```bash
   npm install
   ```

3. **Launch the desktop application**
   ```bash
   npm start
   ```

## What You'll See

### First Run - Configuration Wizard
- **Step 1**: Welcome screen with setup overview
- **Step 2**: Choose model storage location (browse for folder)
- **Step 3**: Select performance settings (context length, model, GPU)
- **Step 4**: Configure privacy settings (airplane mode, network access)
- **Step 5**: Review configuration and launch the app

### Main Application
- **Custom title bar** with minimize/maximize/close controls
- **Sidebar navigation** with Chat, Models, and Settings
- **Chat interface** with welcome screen and quick actions
- **Real-time messaging** with typing indicators
- **Model management** for downloading and managing AI models
- **Settings panel** for adjusting configuration

## Features Implemented

✅ **Electron Application Structure**
- Main process with IPC communication
- Secure preload script
- Custom window management

✅ **Configuration Wizard**
- 5-step guided setup process
- File system integration for folder selection
- Configuration persistence

✅ **Main Application Interface**
- Dark theme matching CruxAGI aesthetic
- Responsive chat interface
- Sidebar with navigation and history
- Settings management

✅ **Build Configuration**
- Cross-platform build setup
- Package configuration for distribution
- Development and production scripts

## Architecture

The desktop application is structured as:
- **main.js**: Electron main process handling windows and IPC
- **preload.js**: Secure bridge between main and renderer processes
- **wizard/**: Initial configuration setup interface
- **app/**: Main application interface after setup
- **package.json**: Build configuration and scripts

## Next Steps

To create distributable packages:
```bash
npm run build    # Create production build
npm run dist     # Create platform-specific installers
```

This will generate installers for Windows (.exe), macOS (.dmg), and Linux (.AppImage/.deb) based on your platform.
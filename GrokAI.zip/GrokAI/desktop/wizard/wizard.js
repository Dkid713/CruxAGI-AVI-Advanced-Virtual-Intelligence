class SetupWizard {
    constructor() {
        this.currentStep = 0;
        this.totalSteps = 5;
        this.config = {
            isFirstRun: false,
            modelLocation: '',
            contextLength: '32k',
            exposeNetwork: false,
            airplaneMode: true,
            selectedModel: 'llama2:7b',
            serverPort: 11434,
            theme: 'dark',
            gpuAcceleration: false
        };
        
        this.initializeWizard();
    }

    async initializeWizard() {
        // Load existing config if any
        try {
            const existingConfig = await window.electronAPI.getConfig();
            this.config = { ...this.config, ...existingConfig };
        } catch (error) {
            console.error('Failed to load config:', error);
        }

        // Set default model location
        if (!this.config.modelLocation) {
            const defaultPath = window.electronAPI.platform === 'win32' 
                ? 'C:\\Users\\' + require('os').userInfo().username + '\\CruxAGI\\models'
                : require('path').join(require('os').homedir(), 'CruxAGI', 'models');
            this.config.modelLocation = defaultPath;
        }

        this.updateUI();
        this.updateProgress();
    }

    nextStep() {
        if (this.currentStep < this.totalSteps - 1) {
            if (this.validateCurrentStep()) {
                this.currentStep++;
                this.showStep(this.currentStep);
                this.updateProgress();
            }
        }
    }

    prevStep() {
        if (this.currentStep > 0) {
            this.currentStep--;
            this.showStep(this.currentStep);
            this.updateProgress();
        }
    }

    showStep(stepIndex) {
        // Hide all steps
        document.querySelectorAll('.wizard-step').forEach(step => {
            step.classList.remove('active');
        });

        // Show current step
        const steps = document.querySelectorAll('.wizard-step');
        if (steps[stepIndex]) {
            steps[stepIndex].classList.add('active');
        }

        // Update step indicators
        document.querySelectorAll('.step-indicator').forEach((indicator, index) => {
            indicator.classList.remove('active', 'completed');
            if (index === stepIndex) {
                indicator.classList.add('active');
            } else if (index < stepIndex) {
                indicator.classList.add('completed');
            }
        });

        // Handle step-specific logic
        if (stepIndex === 4) { // Complete step
            this.showConfigSummary();
        }
    }

    updateProgress() {
        const progress = ((this.currentStep + 1) / this.totalSteps) * 100;
        document.getElementById('progress-fill').style.width = progress + '%';
    }

    validateCurrentStep() {
        switch (this.currentStep) {
            case 0: // Welcome
                return true;
            case 1: // Storage
                return this.validateStorage();
            case 2: // Performance
                return this.validatePerformance();
            case 3: // Privacy
                return this.validatePrivacy();
            case 4: // Complete
                return true;
            default:
                return true;
        }
    }

    validateStorage() {
        const modelLocation = document.getElementById('model-location').value.trim();
        if (!modelLocation) {
            this.showError('Please select a model storage location');
            return false;
        }
        this.config.modelLocation = modelLocation;
        return true;
    }

    validatePerformance() {
        this.config.contextLength = document.getElementById('context-length').value;
        this.config.selectedModel = document.getElementById('model-select').value;
        this.config.gpuAcceleration = document.getElementById('gpu-acceleration').checked;
        return true;
    }

    validatePrivacy() {
        this.config.airplaneMode = document.getElementById('airplane-mode').checked;
        this.config.exposeNetwork = document.getElementById('expose-network').checked;
        this.config.serverPort = parseInt(document.getElementById('server-port').value) || 11434;
        return true;
    }

    updateUI() {
        // Update model location input
        if (this.config.modelLocation) {
            const locationInput = document.getElementById('model-location');
            if (locationInput) {
                locationInput.value = this.config.modelLocation;
            }
        }

        // Update other form fields
        setTimeout(() => {
            const contextSelect = document.getElementById('context-length');
            if (contextSelect) contextSelect.value = this.config.contextLength;

            const modelSelect = document.getElementById('model-select');
            if (modelSelect) modelSelect.value = this.config.selectedModel;

            const airplaneCheck = document.getElementById('airplane-mode');
            if (airplaneCheck) airplaneCheck.checked = this.config.airplaneMode;

            const networkCheck = document.getElementById('expose-network');
            if (networkCheck) networkCheck.checked = this.config.exposeNetwork;

            const portInput = document.getElementById('server-port');
            if (portInput) portInput.value = this.config.serverPort;

            const gpuCheck = document.getElementById('gpu-acceleration');
            if (gpuCheck) gpuCheck.checked = this.config.gpuAcceleration;
        }, 100);
    }

    async selectModelDir() {
        try {
            const selectedPath = await window.electronAPI.selectFolder();
            if (selectedPath) {
                this.config.modelLocation = selectedPath;
                document.getElementById('model-location').value = selectedPath;
                
                // Enable continue button and show storage info
                document.getElementById('storage-next').disabled = false;
                this.showStorageInfo(selectedPath);
            }
        } catch (error) {
            console.error('Error selecting folder:', error);
            this.showError('Failed to select folder');
        }
    }

    async showStorageInfo(path) {
        const infoDiv = document.getElementById('storage-info');
        if (infoDiv) {
            infoDiv.style.display = 'block';
            
            // Check if directory exists
            try {
                const exists = await window.electronAPI.checkDirectory(path);
                document.getElementById('path-status').textContent = exists ? 'Valid' : 'Will be created';
                document.getElementById('path-status').style.color = exists ? '#22c55e' : '#f59e0b';
                
                // Note: In a real implementation, you'd check available space
                document.getElementById('available-space').textContent = 'Checking...';
                setTimeout(() => {
                    document.getElementById('available-space').textContent = '50+ GB available';
                    document.getElementById('available-space').style.color = '#22c55e';
                }, 1000);
            } catch (error) {
                document.getElementById('path-status').textContent = 'Error checking path';
                document.getElementById('path-status').style.color = '#ef4444';
            }
        }
    }

    showConfigSummary() {
        const summaryDiv = document.getElementById('config-summary');
        if (summaryDiv) {
            summaryDiv.innerHTML = `
                <h3 style="margin-bottom: 1rem; color: #ffffff;">Configuration Summary</h3>
                <div class="info-item">
                    <span class="info-label">Model Storage:</span>
                    <span class="info-value">${this.config.modelLocation}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Context Length:</span>
                    <span class="info-value">${this.config.contextLength}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Default Model:</span>
                    <span class="info-value">${this.config.selectedModel}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Privacy Mode:</span>
                    <span class="info-value">${this.config.airplaneMode ? 'Airplane Mode (Local only)' : 'Network enabled'}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Server Port:</span>
                    <span class="info-value">${this.config.serverPort}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">GPU Acceleration:</span>
                    <span class="info-value">${this.config.gpuAcceleration ? 'Enabled' : 'Disabled'}</span>
                </div>
            `;
        }
    }

    async completeSetup() {
        try {
            // Create model directory if it doesn't exist
            if (this.config.modelLocation) {
                await window.electronAPI.createDirectory(this.config.modelLocation);
            }

            // Save configuration and complete setup
            const success = await window.electronAPI.completeSetup(this.config);
            if (success) {
                console.log('Setup completed successfully');
            } else {
                this.showError('Failed to save configuration');
            }
        } catch (error) {
            console.error('Error completing setup:', error);
            this.showError('Setup failed: ' + error.message);
        }
    }

    showError(message) {
        // Simple error display - in a real app you'd want a proper toast/modal
        alert(message);
    }
}

// Global functions for HTML onclick handlers
function nextStep() {
    wizard.nextStep();
}

function prevStep() {
    wizard.prevStep();
}

function selectModelDir() {
    wizard.selectModelDir();
}

function completeSetup() {
    wizard.completeSetup();
}

// Initialize wizard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.wizard = new SetupWizard();
});

// Handle airplane mode checkbox changes
document.addEventListener('change', (event) => {
    if (event.target.id === 'airplane-mode') {
        const exposeNetworkCheckbox = document.getElementById('expose-network');
        if (event.target.checked && exposeNetworkCheckbox) {
            exposeNetworkCheckbox.checked = false;
            exposeNetworkCheckbox.disabled = true;
        } else if (exposeNetworkCheckbox) {
            exposeNetworkCheckbox.disabled = false;
        }
    }
});
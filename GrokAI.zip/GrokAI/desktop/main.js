const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');

// Enable live reload for development
if (process.env.NODE_ENV === 'development') {
  require('electron-reload')(__dirname, {
    electron: path.join(__dirname, '..', 'node_modules', '.bin', 'electron'),
    hardResetMethod: 'exit'
  });
}

class CruxAGIDesktop {
  constructor() {
    this.mainWindow = null;
    this.configPath = path.join(os.homedir(), '.cruxagi');
    this.configFile = path.join(this.configPath, 'config.json');
    this.ensureConfigDir();
  }

  ensureConfigDir() {
    if (!fs.existsSync(this.configPath)) {
      fs.mkdirSync(this.configPath, { recursive: true });
    }
  }

  loadConfig() {
    try {
      if (fs.existsSync(this.configFile)) {
        const config = fs.readFileSync(this.configFile, 'utf8');
        return JSON.parse(config);
      }
    } catch (error) {
      console.error('Error loading config:', error);
    }
    
    return {
      isFirstRun: true,
      modelLocation: path.join(os.homedir(), 'CruxAGI', 'models'),
      contextLength: '32k',
      exposeNetwork: false,
      airplaneMode: true,
      selectedModel: 'llama2:7b',
      serverPort: 11434,
      theme: 'dark'
    };
  }

  saveConfig(config) {
    try {
      fs.writeFileSync(this.configFile, JSON.stringify(config, null, 2));
      return true;
    } catch (error) {
      console.error('Error saving config:', error);
      return false;
    }
  }

  createWindow() {
    const config = this.loadConfig();
    
    this.mainWindow = new BrowserWindow({
      width: 1400,
      height: 900,
      minWidth: 800,
      minHeight: 600,
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true,
        enableRemoteModule: false,
        preload: path.join(__dirname, 'preload.js')
      },
      titleBarStyle: 'hiddenInset',
      backgroundColor: '#0F1419',
      show: false,
      icon: path.join(__dirname, 'assets', 'icon.png')
    });

    // Show configuration wizard on first run
    if (config.isFirstRun) {
      this.showConfigWizard();
    } else {
      this.loadMainApp();
    }

    this.mainWindow.once('ready-to-show', () => {
      this.mainWindow.show();
    });

    this.mainWindow.on('closed', () => {
      this.mainWindow = null;
    });

    // Handle external links
    this.mainWindow.webContents.setWindowOpenHandler(({ url }) => {
      shell.openExternal(url);
      return { action: 'deny' };
    });
  }

  showConfigWizard() {
    const htmlPath = path.join(__dirname, 'wizard', 'index.html');
    this.mainWindow.loadFile(htmlPath);
  }

  loadMainApp() {
    const htmlPath = path.join(__dirname, 'app', 'index.html');
    this.mainWindow.loadFile(htmlPath);
  }

  setupIPC() {
    // Configuration management
    ipcMain.handle('get-config', () => {
      return this.loadConfig();
    });

    ipcMain.handle('save-config', (event, config) => {
      return this.saveConfig(config);
    });

    ipcMain.handle('complete-setup', (event, config) => {
      config.isFirstRun = false;
      const success = this.saveConfig(config);
      if (success) {
        this.loadMainApp();
      }
      return success;
    });

    // File system operations
    ipcMain.handle('select-folder', async () => {
      const result = await dialog.showOpenDialog(this.mainWindow, {
        properties: ['openDirectory'],
        title: 'Select Model Directory'
      });
      
      if (!result.canceled && result.filePaths.length > 0) {
        return result.filePaths[0];
      }
      return null;
    });

    ipcMain.handle('create-directory', async (event, dirPath) => {
      try {
        if (!fs.existsSync(dirPath)) {
          fs.mkdirSync(dirPath, { recursive: true });
        }
        return true;
      } catch (error) {
        console.error('Error creating directory:', error);
        return false;
      }
    });

    ipcMain.handle('check-directory', (event, dirPath) => {
      return fs.existsSync(dirPath) && fs.statSync(dirPath).isDirectory();
    });

    // Application controls
    ipcMain.handle('restart-app', () => {
      app.relaunch();
      app.exit();
    });

    ipcMain.handle('quit-app', () => {
      app.quit();
    });

    ipcMain.handle('minimize-window', () => {
      this.mainWindow.minimize();
    });

    ipcMain.handle('maximize-window', () => {
      if (this.mainWindow.isMaximized()) {
        this.mainWindow.unmaximize();
      } else {
        this.mainWindow.maximize();
      }
    });

    ipcMain.handle('close-window', () => {
      this.mainWindow.close();
    });
  }
}

const cruxagi = new CruxAGIDesktop();

app.whenReady().then(() => {
  cruxagi.createWindow();
  cruxagi.setupIPC();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      cruxagi.createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// Security: Prevent new window creation
app.on('web-contents-created', (event, contents) => {
  contents.on('new-window', (navigationEvent, navigationUrl) => {
    event.preventDefault();
    shell.openExternal(navigationUrl);
  });
});
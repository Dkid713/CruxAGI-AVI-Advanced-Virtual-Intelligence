#!/usr/bin/env python3
# examples/run_demo.py
from tool_sdk.policy import ToolPolicy
from tool_sdk.auditor import Auditor
from tool_sdk.core import ToolRunner
from tool_sdk.tools.http import HttpTool
from tool_sdk.tools.pyexec import PyExecTool
from tool_sdk.tools.sql import SqlTool

def main():
    policy = ToolPolicy.load_from_yaml("examples/policy.example.yaml")
    auditor = Auditor("/tmp/tool_audit.jsonl")
    runner = ToolRunner(policy, auditor)

    http = HttpTool(policy)
    py   = PyExecTool(policy)
    sql  = SqlTool(policy)

    print("🔧 Tool SDK v0 Demo")
    print("=" * 50)

    # HTTP (egress allowlist)
    print("\n📡 HTTP Tool Test:")
    result = runner.run(http, method="GET", url="https://httpbin.org/json")
    print(f"  Status: {result.ok}, Time: {result.elapsed_ms:.1f}ms")
    if result.ok:
        print(f"  HTTP Status: {result.output['status']}")
    else:
        print(f"  Error: {result.error}")

    # Python exec
    print("\n🐍 Python Execution Test:")
    result = runner.run(py, code="_result = sum(range(10))")
    print(f"  Status: {result.ok}, Time: {result.elapsed_ms:.1f}ms")
    if result.ok:
        print(f"  Result: {result.output['result']}")
    else:
        print(f"  Error: {result.error}")

    # SQLite
    print("\n🗄️ SQL Test:")
    result = runner.run(sql, query="select 40+2 as answer")
    print(f"  Status: {result.ok}, Time: {result.elapsed_ms:.1f}ms")
    if result.ok:
        print(f"  Rows: {result.output['rows']}")
    else:
        print(f"  Error: {result.error}")

    print(f"\n📋 Audit log: /tmp/tool_audit.jsonl")
    print("✅ Demo completed!")

if __name__ == "__main__":
    main()
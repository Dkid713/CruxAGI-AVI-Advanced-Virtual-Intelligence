#!/usr/bin/env python3
# tests/test_traces.py
import json
import pytest
from tool_sdk.policy import ToolPolicy
from tool_sdk.auditor import Auditor
from tool_sdk.core import ToolRunner
from tool_sdk.tools.http import HttpTool
from tool_sdk.tools.pyexec import PyExecTool
from tool_sdk.tools.sql import SqlTool

@pytest.fixture
def setup_tools():
    policy = ToolPolicy.load_from_yaml("examples/policy.example.yaml")
    auditor = Auditor("/tmp/test_audit.jsonl")
    runner = ToolRunner(policy, auditor)
    
    tools = {
        "http": HttpTool(policy),
        "pyexec": PyExecTool(policy),
        "sql": SqlTool(policy)
    }
    
    return runner, tools

def load_traces():
    """Load test traces from JSONL file"""
    traces = []
    with open("examples/traces.example.jsonl", "r") as f:
        for line in f:
            if line.strip():
                traces.append(json.loads(line))
    return traces

@pytest.mark.parametrize("trace", load_traces())
def test_tool_trace(setup_tools, trace):
    """Test each tool trace from examples/traces.example.jsonl"""
    runner, tools = setup_tools
    
    tool_name = trace["tool"]
    input_args = trace["input"]
    expected = trace["expected"]
    
    assert tool_name in tools, f"Unknown tool: {tool_name}"
    
    tool = tools[tool_name]
    result = runner.run(tool, **input_args)
    
    # All traces should succeed
    assert result.ok, f"Tool {tool_name} failed: {result.error}"
    
    # Verify expected outputs
    if "status" in expected:
        assert result.output["status"] == expected["status"]
    
    if "result" in expected:
        assert result.output["result"] == expected["result"]
    
    if "rows" in expected:
        assert result.output["rows"] == expected["rows"]
    
    # Performance check - should complete within reasonable time
    assert result.elapsed_ms < 10000, f"Tool {tool_name} took too long: {result.elapsed_ms}ms"

def test_tool_accuracy():
    """Test overall tool accuracy against traces"""
    runner, tools = setup_tools()
    traces = load_traces()
    
    successes = 0
    total = len(traces)
    
    for trace in traces:
        try:
            tool_name = trace["tool"]
            input_args = trace["input"]
            tool = tools[tool_name]
            result = runner.run(tool, **input_args)
            if result.ok:
                successes += 1
        except Exception:
            pass
    
    accuracy = successes / total if total > 0 else 0
    print(f"\n📊 Tool Accuracy: {successes}/{total} ({accuracy:.1%})")
    
    # Target ≥80% accuracy
    assert accuracy >= 0.8, f"Tool accuracy {accuracy:.1%} below 80% threshold"

def test_security_constraints():
    """Test that security policies are enforced"""
    runner, tools = setup_tools()
    
    # Test egress blocking
    http_tool = tools["http"]
    result = runner.run(http_tool, method="GET", url="https://blocked-domain.com")
    assert not result.ok, "HTTP tool should block non-allowlisted domains"
    assert result.error and ("PermissionError" in result.error or "not allowed" in result.error)
    
    # Test timeout enforcement (this should work within limits)
    py_tool = tools["pyexec"]
    result = runner.run(py_tool, code="_result = sum(range(1000))")
    assert result.ok, "Simple Python code should execute successfully"
    assert result.elapsed_ms < 5000, "Should complete within timeout"

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
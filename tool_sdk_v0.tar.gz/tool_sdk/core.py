# tool_sdk/core.py
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, Optional, Protocol
import time, traceback

from .policy import ToolPolicy
from .auditor import Auditor
from .sandbox import temp_workdir, apply_limits

class Tool(Protocol):
    name: str
    def call(self, **kwargs) -> Dict[str, Any]: ...

@dataclass
class ToolResult:
    ok: bool
    output: Any
    error: Optional[str]
    elapsed_ms: float
    meta: Dict[str, Any]

class ToolRunner:
    def __init__(self, policy: ToolPolicy, auditor: Auditor):
        self.policy = policy
        self.auditor = auditor

    def run(self, tool: Tool, **kwargs) -> ToolResult:
        start = time.time()
        with temp_workdir(self.policy.fs.workdir_base) as wd:
            try:
                # Apply resource limits inside the worker process as needed by tools.
                # For pure-Python calls we can apply proactively here:
                apply_limits(self.policy.timeouts.cpu_seconds)
                self.auditor.log("tool_call_started", {
                    "tool": tool.name, "args": list(kwargs.keys()), "workdir": wd
                })
                out = tool.call(**kwargs)  # tool enforces wall timeout & egress rules
                elapsed = (time.time() - start) * 1000
                self.auditor.log("tool_call_finished", {
                    "tool": tool.name, "elapsed_ms": elapsed, "ok": True
                })
                return ToolResult(ok=True, output=out, error=None, elapsed_ms=elapsed, meta={"workdir": wd})
            except Exception as e:
                elapsed = (time.time() - start) * 1000
                err = f"{type(e).__name__}: {e}"
                self.auditor.log("tool_call_failed", {
                    "tool": tool.name,
                    "elapsed_ms": elapsed,
                    "error": err,
                    "trace": traceback.format_exc()[:4000]
                })
                return ToolResult(ok=False, output=None, error=err, elapsed_ms=elapsed, meta={"workdir": wd})
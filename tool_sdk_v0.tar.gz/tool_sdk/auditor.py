# tool_sdk/auditor.py
from __future__ import annotations
import json, time, os
from typing import Any, Dict, Optional

class Auditor:
    def __init__(self, path: str = "/tmp/tool_audit.jsonl"):
        self.path = path
        os.makedirs(os.path.dirname(self.path), exist_ok=True)

    def log(self, event: str, payload: Dict[str, Any]):
        record = {
            "ts": time.time(),
            "event": event,
            **payload,
        }
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
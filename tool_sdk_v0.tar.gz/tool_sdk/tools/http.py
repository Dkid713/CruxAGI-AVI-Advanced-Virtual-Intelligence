# tool_sdk/tools/http.py
from __future__ import annotations
import requests, socket
from urllib.parse import urlparse
from typing import Dict, Any, Optional
from ..policy import ToolPolicy

class HttpTool:
    name = "http"

    def __init__(self, policy: ToolPolicy):
        self.policy = policy

    def _allowed(self, url: str) -> bool:
        if not self.policy.egress.deny_by_default:
            return True
        host = urlparse(url).hostname or ""
        return any(host.endswith(dom) for dom in self.policy.egress.allow_domains)

    def call(self, **kwargs) -> Dict[str, Any]:
        method = kwargs.pop("method", "GET")
        url = kwargs.pop("url", "")
        timeout = kwargs.pop("timeout", None)
        if not url or not self._allowed(url):
            raise PermissionError(f"Egress not allowed to {url}")
        to = timeout or self.policy.timeouts.wall_seconds
        r = requests.request(method=method.upper(), url=url, timeout=to, **kwargs)
        return {
            "status": r.status_code,
            "headers": dict(r.headers),
            "text": r.text[:200_000],  # cap
        }
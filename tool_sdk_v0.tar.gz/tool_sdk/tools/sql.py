# tool_sdk/tools/sql.py
from __future__ import annotations
import sqlite3, json
from typing import Dict, Any
from ..policy import ToolPolicy

class SqlTool:
    name = "sql"

    def __init__(self, policy: ToolPolicy):
        self.policy = policy

    def call(self, **kwargs) -> Dict[str, Any]:
        query = kwargs.get("query", "")
        params = kwargs.get("params", ())
        # In-memory DB per call. For persistent DB, point to cwd-limited file.
        con = sqlite3.connect(":memory:")
        try:
            cur = con.cursor()
            cur.execute(query, params)
            if query.strip().lower().startswith("select"):
                rows = cur.fetchall()
                return {"rows": rows, "rowcount": len(rows)}
            else:
                con.commit()
                return {"rowcount": cur.rowcount}
        finally:
            con.close()
# tool_sdk/tools/pyexec.py
from __future__ import annotations
import subprocess, textwrap, os, json, sys, tempfile
from typing import Dict, Any
from ..policy import ToolPolicy

PY_EXEC_WRAPPER = """\
import sys, json, time
globals_dict = {}
locals_dict = {}
src = sys.stdin.read()
start = time.time()
try:
    exec(src, globals_dict, locals_dict)
    out = locals_dict.get("_result", None)
    print(json.dumps({"ok": True, "result": out, "elapsed": time.time()-start}))
except Exception as e:
    print(json.dumps({"ok": False, "error": f"{type(e).__name__}: {e}", "elapsed": time.time()-start}))
"""

class PyExecTool:
    name = "pyexec"

    def __init__(self, policy: ToolPolicy):
        self.policy = policy

    def call(self, **kwargs) -> Dict[str, Any]:
        code = kwargs.get("code", "")
        wall_timeout = kwargs.get("wall_timeout")
        # Enforce write caps: only inside workdir (runner ensures cwd)
        to = wall_timeout or self.policy.timeouts.wall_seconds
        with tempfile.NamedTemporaryFile("w", delete=False) as wrapper:
            wrapper.write(PY_EXEC_WRAPPER)
            wrapper_path = wrapper.name
        try:
            p = subprocess.run(
                [sys.executable, wrapper_path],
                input=code.encode(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=to,
            )
        except subprocess.TimeoutExpired:
            raise TimeoutError(f"Python exec wall-timeout after {to}s")
        finally:
            os.unlink(wrapper_path)

        if p.returncode != 0 and not p.stdout:
            raise RuntimeError(f"Python exec failed: {p.stderr[:2000]!r}")
        out = json.loads(p.stdout.decode() or "{}")
        if not out.get("ok"):
            raise RuntimeError(out.get("error", "Unknown error"))
        return {"result": out.get("result"), "elapsed": out.get("elapsed")}
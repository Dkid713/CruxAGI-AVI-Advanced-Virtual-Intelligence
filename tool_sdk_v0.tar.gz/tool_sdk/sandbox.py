# tool_sdk/sandbox.py
from __future__ import annotations
import os, tempfile, shutil, resource, signal, time
from contextlib import contextmanager
from typing import Tuple

@contextmanager
def temp_workdir(base: str):
    os.makedirs(base, exist_ok=True)
    d = tempfile.mkdtemp(dir=base, prefix="call_")
    cwd = os.getcwd()
    try:
        os.chdir(d)
        yield d
    finally:
        os.chdir(cwd)
        shutil.rmtree(d, ignore_errors=True)

def apply_limits(cpu_seconds: float, file_bytes_soft: int | None = None):
    # CPU limit
    resource.setrlimit(resource.RLIMIT_CPU, (int(cpu_seconds), int(cpu_seconds)))
    # Address space, core dumps, etc. (tighten as needed)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    if file_bytes_soft:
        resource.setrlimit(resource.RLIMIT_FSIZE, (file_bytes_soft, file_bytes_soft))
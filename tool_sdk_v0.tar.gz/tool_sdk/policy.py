# tool_sdk/policy.py
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
import yaml

@dataclass
class Timeouts:
    wall_seconds: float = 5.0
    cpu_seconds: float = 3.0

@dataclass
class FilesystemCaps:
    workdir_base: str = "/tmp/tool_sandbox"
    max_bytes_per_call: int = 10 * 1024 * 1024  # 10 MB
    allow_read_paths: List[str] = field(default_factory=list)
    allow_write: bool = True

@dataclass
class Egress:
    allow_domains: List[str] = field(default_factory=list)
    deny_by_default: bool = True

@dataclass
class ToolPolicy:
    timeouts: Timeouts = field(default_factory=Timeouts)
    fs: FilesystemCaps = field(default_factory=FilesystemCaps)
    egress: Egress = field(default_factory=Egress)
    # optional cost/latency hints
    hints: Dict[str, Any] = field(default_factory=dict)

    @staticmethod
    def load_from_yaml(path: str) -> "ToolPolicy":
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        def _merge(dataclass_type, defaults, data_section):
            if not data_section:
                return defaults
            merged = dataclass_type(**{**defaults.__dict__, **data_section})
            return merged
        policy = ToolPolicy()
        if "timeouts" in data:
            policy.timeouts = _merge(Timeouts, policy.timeouts, data["timeouts"])
        if "fs" in data:
            policy.fs = _merge(FilesystemCaps, policy.fs, data["fs"])
        if "egress" in data:
            policy.egress = _merge(Egress, policy.egress, data["egress"])
        if "hints" in data:
            policy.hints.update(data["hints"])
        return policy